# AndroidMic – Voice Enhancement mod

## What was added
New menu item **Settings drawer → Audio → Voice enhancement** with 5 switches (all ON by default):

| Switch | What it does |
|---|---|
| Phone noise & echo cancel | Turns on Android's built-in noise suppressor, echo canceller and auto gain (if your phone has them) |
| Remove low rumble | High-pass filter at 100 Hz (handling noise, hum, desk thumps) |
| Reduce boxy sound | EQ: -4 dB at 300 Hz (the "inside a bottle" range) and +2 dB at 3.5 kHz for clarity |
| Noise gate | Lowers the signal ~18 dB between words so room tails and hiss are quieter |
| Even out volume | Compressor (3:1) plus a soft limiter so peaks never clip |

Changes apply the next time you press Connect.

## Files
- NEW  `domain/audio/VoiceProcessor.kt`  (the DSP chain)
- NEW  `ui/home/dialog/voice.kt`          (settings dialog)
- NEW  `.github/workflows/android-apk.yml` (builds the APK on GitHub)
- EDIT `MicAudioManager.kt`, `Preferences.kt`, `Command.kt`, `ForegroundService.kt`,
       `MainViewModel.kt`, `NavigationDrawer.kt`, `res/values/strings.xml`

## Tuning
All numbers (cutoff, gate threshold, compression) are constants at the top of `VoiceProcessor.kt`.
- Gate cuts your quiet words -> lower `GATE_OPEN_DB` (e.g. -44).
- Room noise still leaks through -> raise it (e.g. -36).

## Notes
- Works with Audio Format `i16` (default), `i32` and `f32`. `u8` passes through untouched.
- Choosing the "Unprocessed" audio source disables the phone's own effects on purpose; the custom filters still run.
- This reduces room echo, it cannot fully remove reverb. Mic distance and soft furnishings still matter most.
